function setup() {
  createCanvas(400, 400);
  
  colorMode(RGB, 100);

  describe('A red circle on a gray background. The circle moves from left to right in a loop. It slows down when the mouse is pressed.');
}

function draw() {
  background(80);
  fill(10, 100, 50)

  let circle = frameCount % 100;
  if (mouseIsPressed === true) {
    frameRate(10);
     ellipse(mouseX, mouseY, 30);
  } else {
     ellipse((50+pmouseX), (50+pmouseY), 30);
    frameRate(60);
  }
  if (keyIsPressed === true) {
    fill(0);
  } else {
    fill(255);
}
for (let x = 20; x < 400; x += 20) {
    line(x, 20, x, 380);
}
}