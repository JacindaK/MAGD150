function setup() {
  createCanvas(400, 400);
  
  colorMode(RGB, 100);

  describe('A red circle on a gray background. The circle moves from left to right in a loop. It slows down when the mouse is pressed.');
}

function draw() {
  background(80);

  let circle = frameCount % 100;
  if (mouseIsPressed === true) {
    frameRate(10);
     ellipse(mouseX, mouseY, 30);
  } else {
     ellipse((50+pmouseX), (50+pmouseY), 30);
    frameRate(60);
}
  ellipse(50, 50, 20);
 
}