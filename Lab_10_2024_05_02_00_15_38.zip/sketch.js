function setup() {
  createCanvas(400, 400);
}

p5.prototype.setCenter = function(x, y) {
  if(this.center === undefined) {
   this.center = { x, y }
  }
  this.translate(this.center.x = x, this.center.y = y);
}

p5.prototype.polarEllipses = function(_num, _radiusW, _radiusH, _distance, callback) {
  const _angle = 360/_num;
  for(let i=1; i<=_num; i++) {
    if(callback) {
      const _result = callback(i, _angle, _radiusW, _radiusH, _distance);
      this.polarEllipse(_result[0]*_result[1], _result[2], _result[3], _result[4]);
    }
    else this.polarEllipse(i*_angle, _radiusW, _radiusH, _distance);
  }
  
p5.prototype.polarTriangle = function(_angle, _radius, _distance) {
  this.push();
  this.shiftRotate(_angle, _distance);
  this.triangle(
    this.sin(0), this.cos(0)*-_radius,
    this.sin(this.TWO_PI*1/3)*_radius, this.cos(this.TWO_PI*1/3)*-_radius,
    this.sin(this.TWO_PI*2/3)*_radius, this.cos(this.TWO_PI*2/3)*-_radius
  );
  this.pop();
}

}

function draw() { 
    setCenter(width/2, height/2);
    background(10, 70, 100);
    noStroke();
    fill(13, 150, 50, 180);
      polarTriangle(30, 80, 120);
      polarTriangle(45, 70, 120);
      polarTriangle(80, 70, 120);
      polarTriangle(90, 50, 120);
    fill(13, 146, 185, 190);
      polarEllipses(10, 50, 90, 60);
    fill(25, 248, 200, 110);  
      polarEllipses(10, 10, 50, 60);
    fill(252, 248, 200, 140);
      polarEllipses(10, 5, 30, 40);

}